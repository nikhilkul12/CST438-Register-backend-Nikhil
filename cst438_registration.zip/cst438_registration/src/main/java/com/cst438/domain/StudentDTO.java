package com.cst438.domain;

public record StudentDTO(int studentId, String name, String email, String status) {
	
}

